import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import Header from "../components/Header";
import Card from '../components/Card';
import ApiService from "../services/ApiService";

const ArtDetail = () => {
  const { slug } = useParams();
  const [art, setArt] = useState(null)
  const [data, setData] = useState([])
  const [type, setType] = useState('content')
  
  const fetchArtDetail = async (slug) => {
    try {
      let res = await ApiService.fetchArtDetail(slug)
      setArt(res.data)
    } catch (error) {
      console.log(error)
    }
  }
  const fetchArtRecommendations = async (slug, type) => {
    try {
      let res = await ApiService.fetchArtRecommendations(slug, type)
      console.log(res)
      setData(res.data)
    } catch (error) {
      console.log(error)
    }
  }

  useEffect(() => {
    fetchArtDetail(slug)
    fetchArtRecommendations(slug, type)
  }, [slug, type])

  return (
    <>
      <Header />
      <section className="art-detail-wrapper py-5">
      <div className="container">
        { 
          art
          ?
                <div className="row align-items-start">
                  <div className="col-lg-6 mb-4 mb-lg-0">
                    <figure>
                      <img
                        src={art['Image URL']}
                        className="w-100"
                        alt=""
                      />
                    </figure>
                  </div>
                  <div className="col-lg-6">
                    <div className="art-detail-meta">
                      <div className="custom-flex d-flex flex-column flex-lg-row align-items-lg-center justify-content-between mb-4 mb-lg-0">
                        <div className="h1">{art.Title}</div>
                        <button className="btn btn-custom">
                          <div className="d-inline-flex align-items-center">
                            <i className="far fa-heart mr-2"></i>
                            <span>Save to collections</span>
                          </div>
                        </button>
                      </div>
                      <Link to={'#'} className="d-block author mb-4">{art.Tags}</Link>
                      <ul className="list-unstyled mb-0">
                        <li className="details mb-3"><span>Release Date: </span>1994</li>
                        <li className="details mb-3"><span>Category: </span>{art.Tags}</li>
                        <li className="details mb-3"><span>Rating: </span>2.5/5</li>
                        <li className="details mb-3"><span>Emotion: </span>Happiness</li>
                        <li className="details mb-3"><span>Type: </span>{art['Face/body'].toUpperCase()}</li>
                      </ul>
                    </div>
                    <div className="art-share d-flex align-items-center mt-4">
                        <a href="FIXME:">
                          <i className="fab fa-instagram mr-4" />
                        </a>
                        <a href="FIXME:">
                          <i className="fab fa-twitter mr-4" />
                        </a>
                        <a href="FIXME:">
                          <i className="fab fa-facebook-f mr-4" />
                        </a>
                        <a href="FIXME:">
                          <i className="fab fa-linkedin mr-4" />
                        </a>
                        <a href="FIXME:">
                          <i className="fas fa-link mr-4" />
                        </a>
                    </div>
                  </div>
                </div>
          :
          <span>Loading...</span>
        }       
      </div>
    </section>
      <section className="art-recommendations py-5">
        <div className="container">
          <div className="d-flex align-items-center mb-4">
            <div className="h4 mr-4">Recommendations</div>
            <div className="form-group">
              <select className="form-control" onChange={(e) => setType(e.target.value)} name="type" id="type">
                <option value="content">Content Based Recommendations</option>
                <option value="collab">Collaborative Recommendations</option>
                <option value="hybrid">Hybrid Recommendations</option>
              </select>
            </div>
          </div>
          {
            data.length 
            ?
              <div className="row">
                {
                  data.map(art => (
                    <div className="col-lg-3">
                      <Card art={art} />
                    </div>
                  ))
                }
              </div>
            :
            <span>Loading Recommendations...</span>
          }
        </div>
      </section>
    </>
  );
};

export default ArtDetail;
