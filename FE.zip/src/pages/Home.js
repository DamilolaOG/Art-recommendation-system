import React, { useEffect, useState } from "react";
import Header from "../components/Header";
import Filters from "../components/Filters";
import Grid from "../components/Grid";
import ApiService from "../services/ApiService";
import Pagination from "../components/Pagination";

const Home = () => {

  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(0)
  const [data, setData] = useState([])


  const fetchData = async (page) => {
    try {
      let res = await ApiService.fetchHomePageData(page)
      setTotalPages(res.data.total_pages)
      setData(res.data.data)
      setPage(parseInt(res.data.page))
      console.log(res)
    } catch (error) {
      console.log(error)
    }
  }
  
  

  useEffect(() => {
    fetchData(page)
  }, [page])

  return (
    <>
      <Header />
      <main>
        <section className="grid py-5">
          <div className="container">
            <div className="row">
              <div className="col-lg-3 order-1 order-lg-0">
                <Filters />
              </div>
              <div className="col-lg-9 order-0 order-lg-1">
                <Grid data={data} />
                <Pagination currentPage={page} setPage={setPage} totalPages={totalPages} />
              </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default Home;
