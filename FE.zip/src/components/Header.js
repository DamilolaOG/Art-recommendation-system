import React from 'react'

const Header = () => {
  return (
    <header className="py-4">
        <div className="container">
            <div className="d-flex align-items-center">
                <a className="d-inline-block" href="/">
                    <img src="/assets/images/logo.svg" alt="" />
                </a>
                <ul className="list-unstyled ml-auto">
                    <li className="search-input">
                        <div className="form-group">
                            <input type="text" name="search" placeholder="Search by keyword" id="search"
                                className="form-control" />
                            <i className="fas fa-search"></i>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </header>
  )
}

export default Header