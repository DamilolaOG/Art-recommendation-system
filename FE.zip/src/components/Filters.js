import React from "react";

const Filters = () => {
  return (
    <div className="filters-wrapper">
      <div className="h3 mb-3">Filters</div>
      <div className="filter-group first">
        <div className="filter-item w-100 d-flex align-items-center">
          <input
            type="checkbox"
            id="test"
            aria-label="Checkbox for following text input"
          />
          <div className="ml-2 d-flex align-items-center justify-content-between w-100">
            <label htmlFor="test">Minimalism</label>
            <span>200</span>
          </div>
        </div>
        <div className="filter-item w-100 d-flex align-items-center">
          <input
            type="checkbox"
            id="test"
            aria-label="Checkbox for following text input"
          />
          <div className="ml-2 d-flex align-items-center justify-content-between w-100">
            <label htmlFor="test">Minimalism</label>
            <span>200</span>
          </div>
        </div>
        <div className="filter-item w-100 d-flex align-items-center">
          <input
            type="checkbox"
            id="test"
            aria-label="Checkbox for following text input"
          />
          <div className="ml-2 d-flex align-items-center justify-content-between w-100">
            <label htmlFor="test">Minimalism</label>
            <span>200</span>
          </div>
        </div>
        <div className="filter-item w-100 d-flex align-items-center">
          <input
            type="checkbox"
            id="test"
            aria-label="Checkbox for following text input"
          />
          <div className="ml-2 d-flex align-items-center justify-content-between w-100">
            <label htmlFor="test">Minimalism</label>
            <span>200</span>
          </div>
        </div>
        <div className="filter-item w-100 d-flex align-items-center">
          <input
            type="checkbox"
            id="test"
            aria-label="Checkbox for following text input"
          />
          <div className="ml-2 d-flex align-items-center justify-content-between w-100">
            <label htmlFor="test">Minimalism</label>
            <span>200</span>
          </div>
        </div>
        <button className="mt-3 btn btn-custom w-100">Apply Filter</button>
      </div>
      <div className="filter-group">
        <div className="filter-item">
          <span>Year of release</span>
          <div className="d-flex align-content-center justify-content-between mt-2">
            <input type="text" id="from" className="form-control" />
            <span>to</span>
            <input type="text" id="to" className="form-control" />
          </div>
        </div>
        <button className="mt-3 btn btn-custom w-100">Apply Filter</button>
      </div>
    </div>
  );
};

export default Filters;
