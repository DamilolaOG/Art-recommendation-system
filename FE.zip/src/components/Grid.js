import React from "react";
import Card from "./Card";

const Grid = ({ data }) => {

  return (
    <div className="grid-wrapper">
      <div className="row mx-auto">
        <div className="col-12">
          <div className="h3 mb-4">Featured</div>
        </div>
        {
          data.map(art => (
            <div className="col-lg-4" key={art.ID}>
              <Card art={art} />
            </div>
          ))
        }
      </div>
    </div>
  );
};

export default Grid;
