import React from "react";
import { Link } from "react-router-dom";

const Card = ({art}) => {

  console.log(art)

  return (
    <div className="card">
      {
        art
        ?
        <Link to={`/art/${art.ID}`}>
          <div className="card-body">
            <div className="card-image">
              <figure>
                <img
                  src={art['Image URL']}
                  className="w-100"
                  alt=""
                />
              </figure>
            </div>
            <div className="card-meta">
              <div className="h4">{art.Title.length < 22 ? art.Title : art.Title.substring(0, 22) + '...'}</div>
              <div className="author d-flex align-items-center">
                {/* <div className="h6">{art.Tags.split(',')[0]}</div> */}
                <span>1994</span>
              </div>
            </div>
          </div>
        </Link>
        :
        <span>Loading</span>
      }
    </div>
  );
};

export default Card;
