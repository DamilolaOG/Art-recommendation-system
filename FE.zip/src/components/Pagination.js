import React from 'react'

const Pagination = ({ currentPage, totalPages, setPage }) => {


  return (
    <>
        <ul className='pagination'>
            {
                ((currentPage - 1) > 0)
                ?
                    <li>
                        <button className='pagination-btn' onClick={() => setPage(currentPage - 1)}>
                            { currentPage - 1 }
                        </button>
                    </li>
                :
                    null
            }
            <li>
                <button className='pagination-btn current-page'>
                    { currentPage }
                </button>
            </li>
            {
                ((currentPage + 1) < totalPages)
                ?
                    <li>
                        <button className='pagination-btn' onClick={() => setPage(currentPage + 1)}>
                            { currentPage + 1 }
                        </button>
                    </li>
                :
                    null
            }
        </ul>
    </>
  )
}

export default Pagination