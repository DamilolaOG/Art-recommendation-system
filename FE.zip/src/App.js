import React from 'react'
import Home from './pages/Home'
import './css/style.scss'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ArtDetail from './pages/ArtDetail';


const App = () => {
  return (
    <Router>
      <Routes>
        <Route exact path='/' element={<Home />} />
        <Route path='/art/:slug' element={<ArtDetail />} />
      </Routes>
    </Router>
  )
}

export default App