import axios from "axios";
import history from "../history";

// Fetch Configuration
const fetch = axios.create({
  baseURL: process.env.REACT_APP_BACKEND_URL + "/api/",
  timeout: 60000,
});

const ApiService = {};

// APIs

// FETCH HOME PAGE DATA
ApiService.fetchHomePageData = (page) => {
  return fetch({
    url: `/art-list/?page=${page}`,
    method: "GET",
  });
};

// FETCH ART DETAILS
ApiService.fetchArtDetail = (slug) => {
  return fetch({
    url: `/art-detail/${slug}`,
    method: "GET",
  });
};
// FETCH ART RECOMMENDATIONS
ApiService.fetchArtRecommendations = (slug, type) => {
  return fetch({
    url: `/recommendation/${slug}/${type}`,
    method: "GET",
  });
};

// POST DATA
ApiService.postData = () => {
  return fetch({
    url: "/data",
    method: "POST",
    // headers: {
    //   "public-request": "true",
    // },
  });
};


export default ApiService;